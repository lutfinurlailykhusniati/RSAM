<footer class="footer text-center">
   &copy RS Aisyiyah Muntilan 2018
</footer>