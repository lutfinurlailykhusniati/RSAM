<?php $__env->startSection('content'); ?>
 <div class="page-breadcrumb">
                <div class="row">
                    <div class="col-12 d-flex no-block align-items-center">
                        <h4 class="page-title">Data Poliklinik</h4><br><br>
                    </div>
                </div>
            </div>
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">      
                    <?php if(Session::has('flash_message_error')): ?>
                        <div class="alert-error alert -block">
                            <button type="button" class="close" data-dismiss="alert">x</button>
                            <strong><?php echo session('flash_message_error'); ?></strong>
                        </div>
                    <?php endif; ?>
                    <?php if(Session::has('flash_message_succes')): ?>
                        <div class="alert alert-succes alert-block">
                            <button type="button" class="close" data-dismiss="alert">x</button>
                            <strong><?php echo session('flash_message_succes'); ?></strong>
                        </div>
                    <?php endif; ?>
                    <a href="<?php echo e(url('/tambah-polyclinic')); ?>"  class="btn btn-primary">Tambah Poli</a><br><br>
                        <div class="table-responsive">
                        <table id="zero_config" class="table table-striped table-bordered">
                            <thead>
                            <tr>	
                                <th>ID Poliklinik</th>
                                <th>Nama Poli</th>
                                <th>Aksi</th>
                            </tr>
                            </thead>
                            <tbody>
                            	<?php $__currentLoopData = $polyclinics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $polyclinic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                                <td><?php echo e($polyclinic->id); ?></td>
                                                <td><?php echo e($polyclinic->nama_poliklinik); ?></td>
                                                <td class="center">  
                                                    <a href="<?php echo e(url('/edit-polyclinic/'.$polyclinic->id)); ?>"  class="btn btn-success btn-sm">Edit</a> 
                                                    <a href="<?php echo e(url('/delete-polyclinic/'.$polyclinic->id)); ?>" class="btn btn-danger btn-sm" >Delete</a> 
                                                </td> 
                                </tr>
                              	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                                        </tbody>
                
                                    </table>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.petugasLayout.petugas_design', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>