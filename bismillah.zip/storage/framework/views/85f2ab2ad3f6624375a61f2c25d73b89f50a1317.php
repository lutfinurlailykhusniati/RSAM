<!DOCTYPE html>
<html>
<head>
  <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('backend/assets/images/logo1.png')); ?>">
  <title>Bukti Pendaftaran</title>
  <style type="text/css">
      @media  print {
        html, body {
          width: 111mm;
          height: 146mm;
        }
      }
  </style>
</head>
<body>  
  <br>
        <center><h2>RS. AISYIAH MUNTILAN</h2>
          <hr>
        <p>Jl. KH Admad Dahlan, Pucang Rejo No. 24 Muntilan - Magelang</p></center>
        <div><br>

          <center><div style="text-transform: capitalize; font-size: 18pt">Poli : <?php echo e($poly->nama_poliklinik); ?></div></center>
          <center><div style="text-transform: capitalize; font-size: 14pt">Dokter: <?php echo e($dokter->nama); ?></div></center><br><br><br>
          <center><div style="text-transform: capitalize; font-size: 44pt"><?php echo e($booking->no_antrian); ?></div></center><br><br><br>
          <center><div style=" font-size: 16pt">Nomor RM : <?php echo e($pasien->id); ?></div></center><br>
          <center><div style=" font-size: 16pt; font-weight: bold"><?php echo e($pasien->name); ?></div></center><br>
          <center><div style=" font-size: 16pt"><?php echo e($jadwal->tanggal_jadwal); ?></div></center>
          <center><div style=" font-size: 16pt"><?php echo e($jadwal->jam_mulai); ?> - <?php echo e($jadwal->jam_berakhir); ?></div></center>
        </div>

<script type="text/javascript">
  window.print();
  setTimeout(window.close, 0);
</script>

</body>
</html>