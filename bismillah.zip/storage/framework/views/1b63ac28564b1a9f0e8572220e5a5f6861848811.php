<?php $__env->startSection('content'); ?>
<div class="page-breadcrumb">
                <div class="row">
                    <div class="col-12 d-flex no-block align-items-center">
                        <div class="ml-auto text-right">
                            
                        </div>
                    </div>
                </div>
            </div>
            <div class="container-fluid">
                <div class="card" id="print-kartu">
                    <div class="card-body wizard-content">
                        <h4 class="card-title">Data Pemeriksaan</h4><br>
                        <h6 class="card-subtitle"></h6>
                        <div>
                            <table class="table">
                                <tr>
                                  <td>Nama</td>
                                  <td>:</td>
                                  <td><?php echo e($pasien->name); ?></td>
                                </tr>
                                <tr>
                                  <td>No RM Pasien </td>
                                  <td>:</td>
                                  <td><?php echo e($pasien->id); ?></td>
                                </tr>
                                <tr>
                                  <td>Poli Tujuan</td>
                                  <td>:</td>
                                  <td><?php echo e($poly->nama_poliklinik); ?></td>
                                </tr>
                                <tr>
                                  <td>Dokter</td>
                                  <td>:</td>
                                  <td><?php echo e($dokter->nama); ?></td>
                                </tr>
                                <tr>
                                  <td>Jadwal</td>
                                  <td>:</td>
                                  <td><?php echo e($booking->tanggal_jadwal); ?></td>
                                </tr>
                                <tr>
                                  <td>Jam</td>
                                  <td>:</td>
                                  <td><?php echo e($jadwal->jam_mulai); ?> - <?php echo e($jadwal->jam_berakhir); ?></td>
                                </tr>
                                <tr>
                                  <td>No Antrian</td>
                                  <td>:</td>
                                  <td><?php echo e($booking->no_antrian); ?></td>
                                </tr>
                            </table>
                            <p>*NB : Silahkan Cetak Bukti Pendaftaran atau Screenshot Halaman Data Pemeriksaan ini sebagai bukti pendaftaran online</p>
                            <div style="float: right;">
                            <a target="_blank" href="<?php echo e(url('pendaftaran/print')); ?>/<?php echo e($pasien->id.'/'.$jadwal->id); ?>" class="btn btn-default" >Print</a>
                                <a href="<?php echo e(url('view-pendaftaran')); ?>" class="btn btn-primary" >OK</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('extra-js'); ?>
<script type="text/javascript">
    $('document').ready(function(){
        $("#btn-print").on('click', function(){
            $('#print-kartu').print();
        });
    });
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.petugasLayout.petugas_design', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>