<?php $__env->startSection('content'); ?>

<div class="container-fluid">
    <div class="row">
        <div class="col-md-6">
            <div class="card">
                <form class="form-horizontal" method="post" action="<?php echo e(url('/edit-jadwal/'.$jadwalDetails->id_jadwal.'/'.$jadwalDetails->id_hari)); ?>" id="edit-polyclinic"> <?php echo e(csrf_field()); ?>

                     <div class="card-body">
                        <h4 class="card-title">Edit Jadwal</h4>

                            <div class="form-group row">
                                    <label class="col-md-3 m-t-15">Nama Dokter</label>
                                    <div class="col-md-9">
                                        <select name="dokter_id" id="dokter_id" class="select2 form-control custom-select" style="width: 100%; height:36px;">
                                        <?php $__currentLoopData = $doctors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doctor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($doctor->id); ?>" 
                                            <?php if($doctor->id === $jadwalDetails->dokter_id): ?>
                                            selected
                                            <?php endif; ?>
                                                > <?php echo e($doctor->nama); ?></option>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </select>
                                    </div>
                            </div>
                            

                            <div class="form-group row">
                                <label for="fname" class="col-sm-3  control-label col-form-label">Hari</label>
                                    <div class="col-sm-9">
                                    
                                        <select name="hari" class="form-control">
                                           <?php $__currentLoopData = $haris; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hari): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($hari->id); ?>" 
                                            <?php if($hari->id === $jadwalDetails->id_hari): ?>
                                            selected
                                            <?php endif; ?>
                                                > <?php echo e($hari->hari); ?></option>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    </div>
                            </div>
                            <div class="form-group row">
                                <label for="fname" class="col-sm-3  control-label col-form-label">Jam Mulai</label>
                                <div class="col-sm-9">
                                        <input type="text" class="form-control" name="jam_mulai" id="jam_mulai" placeholder="Jam Mulai" value="<?php echo e($jadwalDetails->jam_mulai); ?>" >
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="fname" class="col-sm-3  control-label col-form-label">Jam Berakhir</label>
                                <div class="col-sm-9">
                                        <input type="text" class="form-control" name="jam_berakhir" id="jam_berakhir" placeholder="Jam Berakhir" value="<?php echo e($jadwalDetails->jam_berakhir); ?>" >
                                </div>
                            </div>


            
                            <div class="form-group row">
                                <label for="fname" class="col-sm-3  control-label col-form-label">Kuota</label>
                                <div class="col-sm-9">
                                        <input type="text" class="form-control" name="kuota" id="kuota" placeholder="Kuota" value="<?php echo e($jadwalDetails->kuota); ?>" >
                                </div>
                            </div>                                                                
                            </div>
                               <div class="form-action">
                                    <div class="card-body">        
                                        <button class="btn btn-primary"  type="Submit">Edit Jadwal</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.petugasLayout.petugas_design', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>