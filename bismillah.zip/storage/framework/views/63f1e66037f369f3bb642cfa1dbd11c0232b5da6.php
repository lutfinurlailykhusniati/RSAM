  <!--banner-->
  <section id="banner" class="banner">
    <div class="bg-color">
      <nav class="navbar navbar-default navbar-fixed-top">
        <div class="container">
          <div class="col-md-12">
            <div class="navbar-header">
              <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
				        <span class="icon-bar"></span>
				        <span class="icon-bar"></span>
				        <span class="icon-bar"></span>
				      </button>
              <a class="navbar-brand" href="#"><img src="<?php echo e(asset('img/logo.png')); ?>" class="img-responsive" style="width: 140px; margin-top: -16px;"></a>
            </div>
           
          </div>
        </div>
      </nav>
      <div class="container">
        <div class="row">
          <div class="banner-info">
            <div class="banner-logo text-center">
              <img src="<?php echo e(asset ('img/logo.png')); ?>" class="img-responsive">
            </div>
            <div class="banner-text text-center">
              <h1 class="white">Selamat Datang !!!</h1>
              <p>Selamat Datang di Sistem Informasi Pendaftaran Online Pemeriksaan Kesehatan RS Aisyiyah Muntilan.</p>
              <a href="#contact" class="btn btn-appoint">Daftar Sekarang!</a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!--/ banner-->
 
<?php echo $__env->make('layouts.app2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>