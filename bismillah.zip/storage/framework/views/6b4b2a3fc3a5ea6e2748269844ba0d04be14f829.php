<?php $__env->startSection('content'); ?>



             <section class="content">
      <div class="box">
  <div class="box-header">
    <div class="row">
        <div class="col-sm-4">
          <h3 class="box-title">Laporan Pendaftaran Online</h3>
        </div>
        <div class="col-sm-10">
            <form class="form-horizontal" role="form" method="POST" action="<?php echo e(route('report.excel')); ?>">
                <?php echo e(csrf_field()); ?>

                <input type="hidden" value="<?php echo e($searchingVals['from']); ?>" name="from" />
                <input type="hidden" value="<?php echo e($searchingVals['to']); ?>" name="to" />
                <button type="submit" class="btn btn-primary" style="float:right">
                  Export to Excel
                </button>
            </form>
        </div>
    </div>
  </div>
  <!-- /.box-header -->
  <div class="box-body">
      <div class="row">
        <div class="col-sm-9"></div>
        <div class="col-sm-9"></div>
      </div>
      <form method="POST" action="<?php echo e(route('report.search')); ?>">
         <?php echo e(csrf_field()); ?>

         <?php $__env->startComponent('layouts.search', ['title' => '']); ?>
          <?php $__env->startComponent('layouts.two-cols-date-search-row', ['items' => ['From', 'To'], 
          'oldVals' => [isset($searchingVals) ? $searchingVals['from'] : '', isset($searchingVals) ? $searchingVals['to'] : '']]); ?>
          <?php echo $__env->renderComponent(); ?>
         <?php echo $__env->renderComponent(); ?>
        
      </form>
      <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">      
              
                        <div class="table-responsive">
                        <table id="zero_config" class="table table-striped table-bordered">
                            <thead>
                            <tr>
                                <th>No RM </th>
                                <th>Nama Pasien </th>
                                <th>Tanggal </th>
                                <th>Waktu</th>
                                <th>No Antrian</th>  
                                <th>Poli</th>  
                                 <th>Nama Dokter</th>                            
                            </tr>
                            </thead>
                            <tbody>
                                
                              <?php $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($booking->Pasien->id); ?></td>
                                    <td><?php echo e($booking->Pasien->name); ?></td>
                                    <td><?php echo e($booking->tanggal_jadwal); ?></td>
                                    <td><?php echo e($booking->jam_mulai); ?> - <?php echo e($booking->jam_berakhir); ?> </td>
                                    <td><?php echo e($booking->no_antrian); ?></td>
                                    <td><?php echo e($booking->Jadwal->Doctor->Polyclinic->nama_poliklinik); ?></td>
                                    <td><?php echo e($booking->Jadwal->Doctor->nama); ?> </td>

                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                                        </tbody>
                
                                    </table>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
   
</div>
    </section>
    <!-- /.content -->
  </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('extra-js'); ?>
<script type="text/javascript">
  $(document).ready(function(){
    $('#golek').on('click', function(){
      $('#golekane').toggle("slow");
  });
});
</script>
  

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.petugasLayout.petugas_design', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>