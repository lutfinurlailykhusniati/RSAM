<?php $__env->startSection('content'); ?>
<!-- <section id="contact" class="section-padding">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <br><br><br><br>
        <h2 class="ser-title">Kontak Kami</h2>
        <hr class="botm-line"><br>
      <div class="col-md-6 col-sm-6">
        <div class="service-info">
          <div class="icon">
            <i class="fa fa-map-marker"></i>
          </div>
        <div class="icon-info">
          <h4>Alamat </h4>
            <p>Jl KH Ahmad Dahlan No 24, Pucungrejo, Muntilan, Magelang Jawa Tengah, 56414</p>
          </div>
        </div><br><br>
        <div class="service-info">
          <div class="icon">
            <i class="fa fa-envelope-o "></i>
          </div>
        <div class="icon-info">
          <h4>Email</h4>
            <p>rs_aisyiyahmuntilan@yahoo.com <br> rsia.muntilan@gmail.com</p>
        </div>
      </div>
    </div>
        <div class="col-md-6 col-sm-6">
          <div class="service-info">
            <div class="icon">
              <i class="fa fa-phone"></i>
            </div>
            <div class="icon-info">
              <h4>Telephone</h4>
              <p>(0293) 5891234</p>
            </div>
          </div><br><br><br>
          <div class="service-info">
            <div class="icon">
              <i class="fa fa-facebook"></i>
            </div>
            <div class="icon-info">
              <h4>Facepage</h4>
              <p>facebook.com/RS-Aisyiyah-Muntilan-111382012919580/</p>
            </div>
          </div>
        </div>
           </form>
          </div>
        </div>
      </div>
    </div>
  </section>

 --> 
 <section id="contact" class="section-padding">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <h2 class="ser-title">Kontak Kami</h2>
          <hr class="botm-line">
        </div>
        <div class="col-md-4 col-sm-4">
          <h3>Kontak Info</h3>
          <div class="space"></div>
          <p><i class="fa fa-map-marker fa-fw pull-left fa-2x"></i>Jl KH Ahmad Dahlan No 24 Pucungrejo<br> Muntilan, Magelang, Jawa tengah, 56414</p>
          <div class="space"></div>
          <p><i class="fa fa-envelope-o fa-fw pull-left fa-2x"></i><p>rs_aisyiyahmuntilan@yahoo.com <br> rsia.muntilan@gmail.com</p>
          <div class="space"></div>
          <p><i class="fa fa-phone fa-fw pull-left fa-2x"></i>(0293) 5891234</p>
        </div>
        <div class="col-md-7 col-sm-7 marb20">
          <div class="contact-info">
            <h3 class="cnt-ttl">Peta</h3>
            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3954.9097350793386!2d110.28288611432419!3d-7.584803877040356!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e7a8bad49d31343%3A0xdf3f775021b9fab1!2sRumah+Sakit+&#39;Aisyiyah+Muntilan!5e0!3m2!1sid!2sid!4v1535820998008" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
          </div>
        </div>
      </div>
    </div>
  </section> <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>