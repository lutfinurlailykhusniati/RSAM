<?php $__env->startSection('content'); ?>

 <div class="page-breadcrumb">
                <div class="row">
                    <div class="col-12 d-flex no-block align-items-center">
                        <h4 class="page-title">Data User</h4><br><br>
                    </div>
                </div>
            </div>
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">      
                                    
                    <?php if($message = Session::get('flash_message_success')): ?>
                                      <div class="alert alert-success alert-block">
                                        <button type="button" class="close" data-dismiss="alert">×</button> 
                                          <strong><?php echo e($message); ?></strong>
                                      </div>
                                    <?php endif; ?>

                                    <?php if($message = Session::get('flash_messgae_error')): ?>
                                      <div class="alert alert-danger alert-block">
                                        <button type="button" class="close" data-dismiss="alert">×</button> 
                                        <strong><?php echo e($message); ?></strong>
                                      </div>
                                    <?php endif; ?>

                                   
                    <a href="<?php echo e(route('user.create')); ?>"  class="btn btn-primary">Tambah User</a><br><br>
                        <div class="table-responsive">
                        <table id="zero_config" class="table table-striped table-bordered">
                            <thead>
                            <tr>
                                <th>Nama </th>
                                <th>Email</th>
                                <th>Level</th>	                      
                                <th>Aksi</th>
                            </tr>
                            </thead>
                            <tbody>
                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>          	
                                <tr>
                                    <td><?php echo e($user->name); ?></td>
                                    <td><?php echo e($user->email); ?></td>
                                    <td><?php echo e($user->level); ?></td>                              
                                    <td class="center">  
                                       <form class="row" method="POST" action="<?php echo e(route('user.destroy', ['id' => $user->id])); ?>" onsubmit = "return confirm('Are you sure?')">
                                         <input type="hidden" name="_method" value="DELETE">
                                         <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                         <a href="<?php echo e(route('user.edit', ['id' => $user->id])); ?>" class="btn btn-success btn-sm ">
                                         Edit
                                         </a>&nbsp;
                                         <?php if($user->name != Auth::user()->name): ?>
                                         <button type="submit" class="btn btn-danger btn-sm ">
                                        Delete
                                        </button>
                                        <?php endif; ?>
                                     </form>
                                    </td> 
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                                        </tbody>
                
                                    </table>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.petugasLayout.petugas_design', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>