<?php $__env->startSection('content'); ?>
<section id="contact" class="section-padding">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <br><br><br><br>
        <h2 class="ser-title">Jadwal Dokter</h2>
        <hr class="botm-line"><br>
        <div class="card">
          <div class="card-body wizard-content">
            <h6 class="card-subtitle"></h6>
              <div class="form-group"><center>
                <label for="exampleInputEmail1" class="col-sm-5"><h4> Pilih Poli</h4></label>
                  <div class="col-sm-5">
                    <select name="poli" class="form-control" id="pilihpoli" >
                    <option value="00">.. Pilih Poli ..</option>
                    <?php $__currentLoopData = $polyclinics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $poly): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($poly->id); ?>"><?php echo e($poly->nama_poliklinik); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                  </div><br><br>
            </div>
            
          </center>     
        </div>
        <div class="card">
          <div class="card-body wizard-content">
            <h6 class="card-subtitle"></h6>
              <div class="form-group"><center>
                <label for="exampleInputEmail1" class="col-sm-5"><h4>Pilih Tanggal</h4></label>
                <div class="col-sm-5">
                <input type="date" name="tanggal" class="form-control" id="tgll" aria-describedby="emailHelp">
            </div></center>     
        </div>
        <!-- <div class="form-group"><center>
            <div class="col-sm-11">                  
            <button type="submit" class="btn btn-primary">Cari</button>
            </div>
        </div> --></center><br><br><br><br><br><br>
        <div id="tabelnya">
            </div>


       <!--  <div class="table-responsive">
            <table id="zero_config" class="table table-striped table-bordered">
                            <thead>
                            <tr>  
                                <th>Nama Dokter</th>
                                <th>Jam Mulai</th>
                                <th>Jam Mulai</th>
                                <th>Jam Berakhir</th>
                                <th>Status</th>
                            </tr>
                            </thead>
                            <tbody>                          
                    </tbody>
            </table>
        </div> -->

                        
        </div>
      </div>
    </div>
  </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('extra-js'); ?>
<script type="text/javascript">
    $('#tgll').on('change', function(){
        var valuex = $(this).val();
        var vulai = $('#pilihpoli').val();
        var isi;   
        $.ajax({
          url: '<?php echo e(url('lihatjadwal/get-jadwal')); ?>/'+vulai+'/'+valuex+'/<?php if(isset($poli)): ?><?php endif; ?>',
          type: 'GET',
          data: "{}",
          contentType: "application/json; charset=utf-8",
          dataType: "json",
          success: function(response) {
            console.log(response[0]);

            isi = '<table class="table"><thead class="thead-light"><tr><td>Nama Dokter</td><td>Hari</td><td>Tanggal</td><td>Jam Mulai</td><td>Jam Berakhir</td><td>Pesan</td></tr></thead><tbody>';
            
            for (var i=0; i<response.length; i++) {
              if(response[i].sisa_kuota){
                isi = isi + '<tr><td>'+response[i].nama+'</td><td>'+response[i].hari+'</td><td>'+response[i].tanggal+'</td><td>'+response[i].jam_mulai+'</td><td>'+response[i].jam_berakhir+'</td><td><span class="label label-primary label-lg" disabled>Tersedia</span></td></tr>';
              }else{
                isi = isi + '<tr><td>'+response[i].nama+'</td><td>'+response[i].tanggal_jadwal+'</td><td>'+response[i].jam_mulai+'</td><td>'+response[i].jam_berakhir+'</td><td><button class="btn btn-danger" disabled>Penuh</button></td></tr>';
              }
            }

            isi = isi + '</tbody></table>';

            document.getElementById("tabelnya").innerHTML= isi;
          },
          error: function(e) {
            alert('gagal');
          }
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>