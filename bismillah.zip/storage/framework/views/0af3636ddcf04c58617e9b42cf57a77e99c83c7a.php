<?php $__env->startSection('content'); ?>
<div class="page-breadcrumb">
                <div class="row">
                    <div class="col-12 d-flex no-block align-items-center">
                        <div class="ml-auto text-right">
                            
                        </div>
                    </div>
                </div>
            </div>
            <!-- ============================================================== -->
            <!-- End Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- Container fluid  -->
            <!-- ============================================================== -->
            <div class="container-fluid">
                <!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                <div class="card">
                    <div class="card-body wizard-content">
                        <h4 class="card-title"></h4>
                        <h6 class="card-subtitle"></h6>
                            <div>
                                <h3>Data Pasien</h3>
                                <table class="table">
                                    <tr>
                                      <td>Nama</td>
                                      <td>:</td>
                                      <td><?php echo e($pasien->name); ?></td>
                                    </tr>
                                    <tr>
                                      <td>Tanggal Lahir</td>
                                      <td>:</td>
                                      <td><?php echo e($pasien->tanggal_lahir); ?></td>
                                    </tr>
                                    <tr>
                                      <td>Tempat Lahir</td>
                                      <td>:</td>
                                      <td><?php echo e($pasien->tempat_lahir); ?></td>
                                    </tr>
                                    <tr>
                                      <td>No Telepon</td>
                                      <td>:</td>
                                      <td><?php echo e($pasien->no_tlp); ?></td>
                                    </tr>

                                </table>
                                
                            </div>
                    </div>
                </div>
            </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.petugasLayout.petugas_design', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>