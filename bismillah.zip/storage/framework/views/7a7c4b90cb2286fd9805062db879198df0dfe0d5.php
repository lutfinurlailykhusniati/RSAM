<?php $__env->startSection('content'); ?>

 <div class="page-breadcrumb">
                <div class="row">
                    <div class="col-12 d-flex no-block align-items-center">
                        <h4 class="page-title">Data Pendaftaran Online</h4><br><br><br>
                    </div>
                </div>
            </div>
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">      
                    <?php if(Session::has('flash_message_error')): ?>
                        <div class="alert-error alert -block">
                            <button type="button" class="close" data-dismiss="alert">x</button>
                            <strong><?php echo session('flash_message_error'); ?></strong>
                        </div>
                    <?php endif; ?>
                    <?php if(Session::has('flash_message_success')): ?>
                        <div class="alert alert-succes alert-block">
                            <button type="button" class="close" data-dismiss="alert">x</button>
                            <strong><?php echo session('flash_message_success'); ?></strong>
                        </div>
                    <?php endif; ?>
                    <a href="<?php echo e(url('/pendaftaran')); ?>"  class="btn btn-primary">Tambah Pendaftaran</a><br><br>
                        <div class="table-responsive">
                        <table id="zero_config" class="table table-striped table-bordered">
                            <thead>
                            <tr>
                                <th>No RM</th>
                                <th>Nama Pasien</th>
                                <th>Tanggal</th>
                                <th>Waktu</th>	
                                <th>No Antrian</th>
                                <th>Poli</th> 
                                <th>Dokter</th>                       
                                <th>Aksi</th>
                            </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>           	
                                <tr>
                                    <td><?php echo e($booking->id_pasien); ?></td>
                                    <td><?php echo e($booking->name); ?></td>
                                    <td><?php echo e($booking->tanggal_jadwal); ?></td>
                                    <td><?php echo e($booking->jam_mulai); ?> - <?php echo e($booking->jam_berakhir); ?></td>
                                    <td><?php echo e($booking->no_antrian); ?></td>
                                    <td><?php echo e($booking->nama_poliklinik); ?></td>
                                    <td><?php echo e($booking->nama); ?></td>
                                                                                                   
                                    <td class="center">  
                                       <!--  <a href="<?php echo e(url('pendaftaran/jadwal', ['id_jadwal' => $booking->id_jadwal, 'id_pasien'=>$booking->id_pasien])); ?>"  class="btn btn-primary btn-sm">Detail</a> -->
                                        <a target="_blank" href="<?php echo e(url('pendaftaran/print', ['id_pasien' => $booking->id_pasien, 'id_jadwal'=>$booking->id_jadwal])); ?>"  class="btn btn-primary btn-sm">Print</a>
                                       <!--  <a href="<?php echo e(url('pendaftaran/done', $booking->id)); ?>" class="btn btn-success btn-sm">Selesai</a>  -->
                                        <a href="<?php echo e(url('pendaftaran/destroy', $booking->id)); ?>"  class="btn btn-danger btn-sm">Batal</a>
                                    </td> 
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                                
                                        </tbody>
                
                                    </table>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.petugasLayout.petugas_design', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>