<?php $__env->startSection('content'); ?>
<section id="contact" class="section-padding">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <br><br><br><br>
        <h2 class="ser-title">Rekap</h2>
        <hr class="botm-line">
        <h4 class="card-title">Data Pemeriksaan</h4><br>
                        <h6 class="card-subtitle"></h6>
                        <div>
                            <table class="table">
                                <tr>
                                  <td>Nama</td>
                                  <td>:</td>
                                  <td><?php echo e($pasien->name); ?></td>
                                </tr>
                                <tr>
                                  <td>Tanggal Lahir</td>
                                  <td>:</td>
                                  <td><?php echo e($pasien->tanggal_lahir); ?></td>
                                </tr>
                                <tr>
                                  <td>Tempat Lahir</td>
                                  <td>:</td>
                                  <td><?php echo e($pasien->tempat_lahir); ?></td>
                                </tr>
                                  <td>Poli</td>
                                  <td>:</td>
                                  <td><?php echo e($poly->nama_poliklinik); ?></td>
                                </tr>
                                <tr>
                                  <td>Dokter</td>
                                  <td>:</td>
                                  <td><?php echo e($dokter->nama); ?></td>
                                </tr>
                                <tr>
                                  <td>Jadwal</td>
                                  <td>:</td>
                                  <td><?php echo e($jadwal->tanggal_jadwal); ?></td>
                                </tr>
                                <tr>
                                  <td>Jam</td>
                                  <td>:</td>
                                  <td><?php echo e($jadwal->jam_mulai); ?> - <?php echo e($jadwal->jam_berakhir); ?></td>
                                </tr>
                                 <tr>
                                  <td>No Antrian</td>
                                  <td>:</td>
                                  <td><?php echo e($booking->no_antrian); ?></td>
                                </tr>
                            </table>
                            <p>*NB : Silahkan Cetak Bukti Pendaftaran atau Screenshot Halaman Data Pemeriksaan ini sebagai bukti pendaftaran online</p>
                            <div style="float: right;">
                            <a target="_blank" href="<?php echo e(url('daftar/print')); ?>/<?php echo e($pasien->id.'/'.$jadwal->id); ?>" class="btn btn-default" >Print</a>
                                <a href="<?php echo e(url('/')); ?>" class="btn btn-primary" >OK</a> 
                            </div>
                        </div>
      </div>
    </div>
  </div>

</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('extra-js'); ?>
<script type="text/javascript">
    $('#pilihpoli').on('change', function(){
        var valuex = $(this).val();
        var isi;   
        $.ajax({
          url: '<?php echo e(url('pendaftaran/get-jadwal')); ?>/'+valuex+'/<?php if(isset($pasien)): ?><?php echo e($pasien->id); ?><?php endif; ?>',
          type: 'GET',
          data: "{}",
          contentType: "application/json; charset=utf-8",
          dataType: "json",
          success: function(response) {
            console.log(response[0]);

            isi = '<table class="table"><thead class="thead-light"><tr><td>Nama Dokter</td><td>Tanggal Jadwal</td><td>Jam Mulai</td><td>Jam Berakhir</td><td>Pesan</td></tr></thead><tbody>';
            
            for (var i=0; i<response.length; i++) {
              if(response[i].sisa_kuota){
                isi = isi + '<tr><td>'+response[i].nama+'</td><td>'+response[i].tanggal_jadwal+'</td><td>'+response[i].jam_mulai+'</td><td>'+response[i].jam_berakhir+'</td><td><a class="btn btn-primary" href="<?php echo e(url("pendaftaran/jadwal")); ?>/'+response[i].id+'/<?php if(isset($pasien)): ?><?php echo e($pasien->id); ?><?php endif; ?>">Pilih</a></td></tr>';
              }else{
                isi = isi + '<tr><td>'+response[i].nama+'</td><td>'+response[i].tanggal_jadwal+'</td><td>'+response[i].jam_mulai+'</td><td>'+response[i].jam_berakhir+'</td><td><button class="btn btn-danger" disabled>Penuh</button></td></tr>';
              }
            }

            isi = isi + '</tbody></table>';

            document.getElementById("tabelnya").innerHTML= isi;

          },
          error: function(e) {
            alert('gagal');
          }
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>